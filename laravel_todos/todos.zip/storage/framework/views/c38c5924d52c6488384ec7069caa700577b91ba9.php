<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ToDo</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap-4.0.0/css/bootstrap.css">
	<script src="vendor/JQuery/jquery-3.3.1.min.js"></script>
	<script src="vendor/JQuery/popper.min.js"></script>
	<script src="vendor/bootstrap-4.0.0/js/bootstrap.js"></script>
</head>
<body style="background-color: #e9e9e9;">
	<div class="container">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
			<a class="navbar-brand" href="#">Todos</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav pull-right">
				</ul>
				<ul class="navbar-nav ml-auto">
					<?php if(Auth::check()): ?>
					<li class="nav-item">
						<a class="nav-link" href="#Profile">Xin chào: <?php echo e(Auth::User()->display_name); ?></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="dangxuat">Đăng xuất</a>
					</li>
					<?php else: ?>
					<li class="nav-item">
						<a class="nav-link" href="dangnhap">Đăng nhập</a>
					</li>
					<?php endif; ?>
				</ul>
			</div>  
		</nav>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<p id="todos">todos</p>
				<div id="boder"></div>
				<i class="fas fa-angle-double-down" id="angle"></i>
				<input type="text" name="" id="inputtext" placeholder="What needs tobe done?">	
				<ul id="list">

					<li id="li" onclick="edit('id');"><i class="fas fa-check correct"></i><label>&nbsp Nội dung</label><i class="fas fa-times closes" onclick="dong('dong')"></i></li>
				</ul>
				<div id="footer">
					<p>Double-click to edit todo</p>
					<p>Create by ............</p>
				</div>
			</div>
		</div>
	</div>
	<!-- <script src="../js/todos.js"></script> -->
</body>
</html>