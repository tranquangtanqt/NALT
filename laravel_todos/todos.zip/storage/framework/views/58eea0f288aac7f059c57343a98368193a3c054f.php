<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>ToDo</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.12/css/all.css" integrity="sha384-G0fIWCsCzJIMAVNQPfjH08cyYaUtMwjJwqiRKxxE/rx96Uroj1BtIQ6MLJuheaO9" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap-4.0.0/css/bootstrap.css">
	<script src="vendor/JQuery/jquery-3.3.1.min.js"></script>
	<script src="vendor/JQuery/popper.min.js"></script>
	<script src="vendor/bootstrap-4.0.0/js/bootstrap.js"></script>
</head>
<body style="background-color: #e9e9e9;">
	<?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-8 offset-md-2">
				<p id="todos">todos</p>
				<div id="boder"></div>
				<i class="fas fa-angle-double-down" id="angle"></i>
				<input type="text" name="" id="inputtext" placeholder="What needs tobe done?">	
				<ul id="list">
					<?php if(Auth::check()): ?>
						<?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(($td->checked == 1)): ?>
							<li id="li<?php echo e($td->id); ?>" onclick="edit(<?php echo e($td->id); ?>);" class="checked">
								<i class="fas fa-check correct i1_checked"></i>
								<label class="checked"> <?php echo e($td->content); ?></label>
								<i class="fas fa-times closes i2_checked" onclick="dong(<?php echo e($td->id); ?>)"></i>
							</li>
						<?php else: ?>
							<li id="li<?php echo e($td->id); ?>" onclick="edit(<?php echo e($td->id); ?>);">
								<i class="fas fa-check correct"></i>
								<label> <?php echo e($td->content); ?></label>
								<i class="fas fa-times closes" onclick="dong(<?php echo e($td->id); ?>)"></i>
							</li>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
				</ul>
				<div id="footer">
					<p>Double-click to edit todo</p>
					<p>Create by ............</p>
				</div>
			</div>
		</div>
	</div>
	<script src="js/todos.js"></script>
	<?php if(session('thongbao')): ?>
	<script>alert(<?php echo e(session('thongbao')); ?>)</script>
	<?php endif; ?>
</body>
</html>